hazelcast-member controls Hazelcast member instance(s) on the local machine

Usage:  hazelcast-member COMMAND

Basic Commands:
  logs        display logs for a member
  start       start a Hazelcast member
  status      display process status for started members
  stop        stop a member

Other Commands:
  list        print started members IDs
  usage       display usage information

Options:
  -h or --help
        display usage and options

  -v or --version
        print Hazelcast version

Run 'hazelcast-member help COMMAND' for more information on a command.
