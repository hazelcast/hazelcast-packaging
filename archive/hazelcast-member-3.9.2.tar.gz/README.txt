Run a new Hazelcast member instance with:

    $ hazelcast-member start

Stop a running member instance with:

    $ hazelcast-member stop

Inspect a current member instance status with:

    $ hazelcast-member status
